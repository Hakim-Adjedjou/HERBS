window.addEventListener('scroll', function() {
    const header = document.getElementById('main-header');
    if (window.scrollY > 50) {
        header.classList.add('sticky');
    } else {
        header.classList.remove('sticky');
    }
});
const collapsibles = document.querySelectorAll(".collapsible");

collapsibles.forEach(button => {
    button.addEventListener("click", function() {
        this.classList.toggle("active");

        const content = this.nextElementSibling;
        if (this.classList.contains("active")) {
            // Expand
            content.style.maxHeight = content.scrollHeight + "px"; // Set to full height
            content.style.padding = "1rem 2rem"; // Expand padding
        } else {
            // Collapse
            content.style.maxHeight = "0";
            content.style.padding = "0 2rem"; // Collapse padding
        }
    });
});
//
// const accordionButtons = document.querySelectorAll(".accordion-button");
//
// accordionButtons.forEach(button => {
//     button.addEventListener("click", function() {
//         // Toggle the active state
//         this.parentElement.classList.toggle("active");
//
//         // Get the associated content
//         const content = this.nextElementSibling;
//
//         if (this.parentElement.classList.contains("active")) {
//             content.style.maxHeight = content.scrollHeight + "px"; // Expand
//         } else {
//             content.style.maxHeight = "0"; // Collapse
//         }
//     });
// });

const track = document.querySelector('.carousel-track');
const cards = document.querySelectorAll('.carousel-card');
let currentIndex = 0;
const cardWidth = cards[0].offsetWidth + 32; // Card width + margin

// Clone the first few cards and append them to the end
cards.forEach(card => {
    const clone = card.cloneNode(true);
    track.appendChild(clone);
});

function slideCarousel() {
    currentIndex++;
    track.style.transition = 'transform 0.5s ease';
    track.style.transform = `translateX(${-currentIndex * cardWidth}px)`;

    // If we've reached the cloned cards, reset to the start seamlessly
    if (currentIndex >= cards.length) {
        setTimeout(() => {
            track.style.transition = 'none'; // Disable animation
            track.style.transform = 'translateX(0)'; // Jump back to the start
            currentIndex = 0; // Reset the index
        }, 500); // Match the transition duration
    }
}

// Automatically slide every 3 seconds
setInterval(slideCarousel, 3000);
