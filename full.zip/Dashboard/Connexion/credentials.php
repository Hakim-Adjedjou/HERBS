<?php
global $db;
require '../db.php';  // Your existing database connection

// Admin credentials
$username = 'admin';
$password = 'securepassword123';  // Change this to the desired password

// Hash the password using bcrypt
$passwordHash = password_hash($password, PASSWORD_BCRYPT);

// Insert into the admin table
$stmt = $db->prepare("INSERT INTO admin (username, password_hash) VALUES (:username, :password_hash)");
$stmt->execute([':username' => $username, ':password_hash' => $passwordHash]);

echo "Admin account created successfully!";
?>

