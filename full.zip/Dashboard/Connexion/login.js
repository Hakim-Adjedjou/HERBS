document.getElementById('login-form').addEventListener('submit', function (event) {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    // Basic client-side validation
    if (username === '' || password === '') {
        event.preventDefault();
        document.getElementById('error-message').textContent = 'Please fill in all fields.';
        document.getElementById('error-message').style.display = 'block';
    }
});
