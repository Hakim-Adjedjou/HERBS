<?php
session_start();  // Start a session to store the login state
global $db;
require __DIR__ . '/../db.php';


// Check if form data was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Fetch admin details from the database
    $stmt = $db->prepare("SELECT * FROM admin WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($admin && password_verify($password, $admin['password_hash'])) {
        // Correct login, set session variable and redirect
        $_SESSION['logged_in'] = true;
        header('Location: ../portail_admin/Demande_inscription/Demande_inscription.php');  // Redirect to the main page
        exit;
    } else {
        // Incorrect login, display error message
        header('Location: login.html?error=1');
        exit;
    }
}
?>

