<?php
session_start();  // Start session
session_destroy();  // Destroy session data
header('Location: ../Connexion/login.html');  // Redirect to login page
exit;
?>

