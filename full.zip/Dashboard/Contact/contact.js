// Get form elements
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const messageInput = document.getElementById("message");
const alertMessage = document.getElementById("alert-message");


// Form validation before submission
document.getElementById("contact-form").addEventListener("submit", (e) => {
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const message = messageInput.value.trim();

    // Check if fields are empty
    if (!name || !email || !message) {
        e.preventDefault();
        alertMessage.textContent = "Tous les champs sont obligatoires.";
        return;
    }

    // Check if email is valid
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        e.preventDefault();
        alertMessage.textContent = "Veuillez entrer une adresse email valide.";

        return;
    }
    const tooltip = document.getElementById("tooltip");

    // Check if message length is sufficient
    if (message.length < 20) {
        e.preventDefault();

        // Position the tooltip
        const rect = messageInput.getBoundingClientRect();
        tooltip.style.top = `${rect.bottom + window.scrollY + 5}px`; // Position below input
        tooltip.style.left = `${rect.left + window.scrollX}px`; // Align with input
        tooltip.style.display = "block";

        // Hide tooltip after 3 seconds
        setTimeout(() => {
            tooltip.style.display = "none";
        }, 3000);

        return;
    }
});