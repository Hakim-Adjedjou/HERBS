<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dotenv\Dotenv;

require '../vendor/autoload.php'; // Include PHPMailer and dotenv autoload file

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    $mail = new PHPMailer(true);

    try {
        // SMTP configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = $_ENV['SMTP_USERNAME']; // Load from environment variables
        $mail->Password = $_ENV['SMTP_PASSWORD']; // Load from environment variables
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Email settings
        $mail->setFrom($_ENV['SMTP_USERNAME'], 'ContactF&H');
        $mail->addAddress('ih_adjedjou@esi.dz');
        $mail->Subject = 'Nouveau message reçu association F&H';
        $mail->Body = "Name: $name\nEmail: $email\n\nMessage:\n$message";

        $mail->send();
        // Success Animation
        echo '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Message Sent</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    margin: 0;
                    background-color: #f9f9f9;
                }
                .success-container {
                    text-align: center;
                }
                .checkmark {
                    font-size: 50px;
                    color: green;
                }
                .message {
                    font-size: 1.5em;
                    color: #333;
                    margin-top: 10px;
                }
                .redirect-message {
                    font-size: 1em;
                    color: #666;
                    margin-top: 20px;
                    display: none;
                }
                .loading {
                    border: 4px solid #f3f3f3; /* Light grey */
                    border-top: 4px solid #3498db; /* Blue */
                    border-radius: 50%;
                    width: 30px;
                    height: 30px;
                    animation: spin 1s linear infinite;
                    display: none;
                    margin: 10px auto;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        </head>
        <body>
            <div class="success-container">
                <div class="checkmark" id="checkmarksign">✔️</div>
                <div class="message">Message envoyé avec succès !</div>
                <div class="loading"></div>
                <div class="redirect-message">Redirection vers la page d\'accueil<span id="dots">...</span></div>
            </div>
            <script>
                const checkmarksign = document.getElementById("checkmarksign"); // Select the checkmark element
                const messageDiv = document.querySelector(".message");
                const loadingDiv = document.querySelector(".loading");
                const redirectDiv = document.querySelector(".redirect-message");
                const dotsSpan = document.getElementById("dots");

                // Change message after 2 seconds
                setTimeout(() => {
                    checkmarksign.style.display = "none"; // Hide the checkmark
                    messageDiv.style.display = "none"; // Hide success message
                    loadingDiv.style.display = "block"; // Show loading animation
                    redirectDiv.style.display = "block"; // Show redirect message
                }, 2000);

                // Animate dots in the redirect message
                setInterval(() => {
                    const dots = dotsSpan.textContent;
                    if (dots.length < 3) {
                        dotsSpan.textContent += ".";
                    } else {
                        dotsSpan.textContent = ".";
                    }
                }, 500);

                // Redirect after 5 seconds
                setTimeout(() => {
                    window.location.href = "../index.html"; // Replace with your accueil page
                }, 4000);
            </script>
        </body>
        </html>
        ';
    } catch (Exception $e) {
        echo "Failed to send the message. Error: {$mail->ErrorInfo}";
    }
}
?>