<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Paiement Annulé</title>
</head>
<body>
<h1>Paiement Annulé</h1>
<p>Votre paiement a été annulé. Vous pouvez réessayer à tout moment.</p>
</body>
</html>
