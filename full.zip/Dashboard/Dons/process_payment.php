<?php

global $db;
require 'vendor/autoload.php';  // Make sure Stripe is installed via Composer
require __DIR__ . '/../db.php';  // Connect to the database

use Stripe\Stripe;
use Stripe\Checkout\Session;

header('Content-Type: application/json');

// Stripe API keys
$stripeSecretKey = 'sk_test_51QqcZv2MdVHDZJT5o3Mq8uYx5p1eitdAiKpnU8yQJqaIFK1AKL3WMwyHRI5a3djngQSbHdNP5pMSOwHlCY8CiMmj00PGrugGga';
Stripe::setApiKey($stripeSecretKey);

// Get POST data
$donationType = $_POST['donation_type'];
$amount = $_POST['amount'];
$firstName = $_POST['first_name'];
$lastName = $_POST['last_name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];

// Check if member exists for 'cotisation_annuelle'
if ($donationType === 'cotisation_annuelle') {
    $stmt = $db->prepare("SELECT id 
FROM members 
WHERE first_name = :first_name 
  AND last_name = :last_name 
  AND (email = :email OR phone = :phone)
");
    $stmt->bindParam(':first_name', $firstName);
    $stmt->bindParam(':last_name', $lastName);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->execute();

    $member = $stmt->fetch();

    if (!$member) {
        echo json_encode(['success' => false, 'message' => "Ce membre n'existe pas."]);
        exit;
    }
    $memberId = $member['id'];
} else {
    $memberId = null;
}

// Create Stripe Checkout Session
try {
    $checkoutSession = Session::create([
        'payment_method_types' => ['card'],
        'line_items' => [[
            'price_data' => [
                'currency' => 'eur',
                'product_data' => [
                    'name' => $donationType === 'cotisation_annuelle' ? 'Cotisation Annuelle' : 'Don',
                ],
                'unit_amount' => $amount * 100,  // Stripe uses cents
            ],
            'quantity' => 1,
        ]],
        'mode' => 'payment',
        'success_url' => 'success/success.php',
        'cancel_url' => 'fail/fail.php',
    ]);

    // Insert into donations table
    $stmt = $db->prepare("INSERT INTO donations (member_id, first_name, last_name, email, amount, donation_type, payment_intent_id) VALUES (:member_id, :first_name, :last_name, :email, :amount, :donation_type, :payment_intent_id)");
    $stmt->bindParam(':member_id', $memberId);
    $stmt->bindParam(':first_name', $firstName);
    $stmt->bindParam(':last_name', $lastName);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':amount', $amount);
    $stmt->bindParam(':donation_type', $donationType);
    $stmt->bindParam(':payment_intent_id', $checkoutSession->id);
    $stmt->execute();

    echo json_encode(['success' => true, 'payment_url' => $checkoutSession->url]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erreur lors du traitement du paiement.']);
}
?>

