document.addEventListener('DOMContentLoaded', function () {
    // Utility function to display error messages
    function showError(message) {
        document.getElementById('response-message').style.display = 'block';
        document.getElementById('response-message').textContent = message;
    }

    // Utility function to validate names
    function isValidName(name) {
        const nameRegex = /^[a-zA-ZÀ-ÿ' -]+$/;
        return nameRegex.test(name);
    }

    // Utility function to validate phone numbers
    function isValidPhoneNumber(phoneNumber) {
        const phoneRegex = /^\+?[0-9\s]+$/;
        return phoneRegex.test(phoneNumber);
    }

    // Utility function to validate email addresses
    function isValidEmail(email) {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return emailRegex.test(email);
    }

    // Handle form submission
    document.getElementById('donation-form').addEventListener('submit', function (e) {
        e.preventDefault();  // Prevent the default form submission

        // Gather input values
        const firstName = document.getElementById('first_name').value.trim();
        const lastName = document.getElementById('last_name').value.trim();
        const email = document.getElementById('email').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const amount = document.getElementById('amount').value.trim();

        // Validation checks
        if (!isValidName(firstName)) {
            showError('Veuillez entrer un prénom valide.');
            return;
        }

        if (!isValidName(lastName)) {
            showError('Veuillez entrer un nom valide.');
            return;
        }

        if (!isValidEmail(email)) {
            showError('Veuillez entrer une adresse e-mail valide.');
            return;
        }

        if (phone && !isValidPhoneNumber(phone)) {
            showError('Veuillez entrer un numéro de téléphone valide.');
            return;
        }

        if (isNaN(amount) || amount <= 0) {
            showError('Veuillez entrer un montant valide supérieur à 0.');
            return;
        }

        // If validation passes, proceed with the payment request
        const formData = new FormData(this);

        fetch('process_payment.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = data.payment_url;  // Redirect to Stripe Checkout
                } else {
                    showError(data.message);  // Display server error
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showError('Erreur inattendue.');
            });
    });

    // Handle donation type changes
    document.getElementById('donation-type').addEventListener('change', function () {
        const amountInput = document.getElementById('amount');
        if (this.value === 'cotisation_annuelle') {
            amountInput.value = 30;  // Set to 30 EUR
            amountInput.readOnly = true;  // Prevent editing
            amountInput.style.backgroundColor = '#e0e0e0';  // Grey out the input field
            amountInput.style.cursor = 'not-allowed';  // Indicate that it’s not editable
        } else {
            amountInput.value = '';  // Clear amount for normal donations
            amountInput.readOnly = false;  // Allow editing
            amountInput.style.backgroundColor = '';  // Reset the background color
            amountInput.style.cursor = '';  // Reset the cursor
        }
    });
});

