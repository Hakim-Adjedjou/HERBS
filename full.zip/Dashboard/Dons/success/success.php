<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Paiement Réussi</title>
</head>
<body>
<h1>Merci pour votre paiement !</h1>
<p>Votre paiement a été traité avec succès.</p>
</body>
</html>
