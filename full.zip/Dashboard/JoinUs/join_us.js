document.getElementById('join-us-form').addEventListener('submit', function (e) {
    e.preventDefault();  // Prevent the default form submission

    // Get field values and trim whitespace
    const firstName = document.getElementById('first_name').value.trim();
    const lastName = document.getElementById('last_name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const email = document.getElementById('email').value.trim();
    const address = document.getElementById('address').value.trim();
    const agreementChecked = document.getElementById('agreement').checked;
    const cotisationChecked = document.getElementById('cotisation').checked;

    // Validation checks for all fields
    if (!firstName || !isValidName(firstName)) {
        showError('Le prénom est invalide. Il ne doit pas contenir de chiffres ni de caractères spéciaux.');
        return;
    }

    if (!lastName || !isValidName(lastName)) {
        showError('Le nom est invalide. Il ne doit pas contenir de chiffres ni de caractères spéciaux.');
        return;
    }

    if (!address) {
        showError('L\'adresse ne peut pas être vide.');
        return;
    }

    if (!phone || !isValidPhoneNumber(phone)) {
        showError('Le numéro de téléphone est invalide. Il doit commencer par "+" (facultatif) et contenir uniquement des chiffres et des espaces.');
        return;
    }

    if (!email || !isValidEmail(email)) {
        showError('L\'adresse email est invalide. Veuillez entrer une adresse correcte.');
        return;
    }

    if (!agreementChecked || !cotisationChecked) {
        showError('Veuillez accepter les conditions et la cotisation.');
        return;
    }

    // Create a new FormData object and add the validated fields
    const formData = new FormData();
    formData.append('first_name', firstName);
    formData.append('last_name', lastName);
    formData.append('address', address);
    formData.append('phone', phone);
    formData.append('email', email);

    // Send the data using fetch
    fetch('join_us.php', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.querySelector(".message").style.display = 'block';  // Show success message
                setTimeout(() => {
                    document.querySelector(".message").style.display = 'none';
                    document.querySelector(".loading").style.display = 'block';  // Show loading animation
                    document.querySelector(".redirect-message").style.display = 'block';  // Show redirect message
                }, 2000);

                // Animate dots
                const dotsSpan = document.getElementById('dots');
                setInterval(() => {
                    const dots = dotsSpan.textContent;
                    dotsSpan.textContent = dots.length < 3 ? dots + "." : ".";
                }, 500);

                // Redirect after 4 seconds
                setTimeout(() => {
                    window.location.replace("../index.html");  // Redirect to accueil page
                }, 4000);
            } else {
                showError(`Erreur : ${data.message}`);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Une erreur inattendue s’est produite. Veuillez réessayer.');
        });
});

// Utility function to display error messages
function showError(message) {
    document.getElementById('response-message').style.display = 'block';
    document.getElementById('response-message').textContent = message;
}

// Utility function to validate names
function isValidName(name) {
    const nameRegex = /^[a-zA-ZÀ-ÿ' -]+$/;
    return nameRegex.test(name);
}

// Utility function to validate phone numbers
function isValidPhoneNumber(phoneNumber) {
    const phoneRegex = /^\+?[0-9\s]+$/;
    return phoneRegex.test(phoneNumber);
}

// Utility function to validate email addresses
function isValidEmail(email) {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
}

