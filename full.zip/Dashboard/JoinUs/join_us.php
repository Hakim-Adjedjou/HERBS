<?php
header('Content-Type: application/json');
global $db;
require '../db.php';  // Include your database connection

try {
    // Validate form data
    if (
        !isset($_POST['first_name']) || !isset($_POST['last_name']) ||
        !isset($_POST['address']) || !isset($_POST['phone']) ||
        !isset($_POST['email'])
    ) {
        echo json_encode(['success' => false, 'message' => 'Invalid form data']);
        exit;
    }

    // Sanitize inputs
    $firstName = trim($_POST['first_name']);
    $lastName = trim($_POST['last_name']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);

    // Insert data into the registrations table
    $stmt = $db->prepare(
        "INSERT INTO registrations (first_name, last_name, address, phone, email) 
         VALUES (:first_name, :last_name, :address, :phone, :email)"
    );
    $stmt->bindParam(':first_name', $firstName);
    $stmt->bindParam(':last_name', $lastName);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':email', $email);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save data']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>

