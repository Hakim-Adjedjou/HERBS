try {
    const track = document.querySelector('.carousel-track');
    const items = Array.from(document.querySelectorAll('.carousel-item'));

    const totalItems = items.length;
    let currentIndex = 0;
    let intervalId;

    // Clone the first 3 and last 3 items for seamless looping
    for (let i = 0; i < 3; i++) {
        const firstClone = items[i].cloneNode(true);
        const lastClone = items[totalItems - 1 - i].cloneNode(true);

        track.appendChild(firstClone);  // Clone at the end
        track.insertBefore(lastClone, track.firstChild);  // Clone at the beginning
    }

    // Set initial position (move to the cloned set)
    const itemWidth = items[0].getBoundingClientRect().width;
    track.style.transform = `translateX(${-itemWidth * 3}px)`;  // Offset for 3 cloned items

    function slideNext() {
        currentIndex++;

        track.style.transition = 'transform 0.5s ease-in-out';
        track.style.transform = `translateX(${-itemWidth * (currentIndex + 3)}px)`;  // Slide by 1 item

        track.addEventListener('transitionend', handleLoop, { once: true });
    }

    function handleLoop() {
        if (currentIndex === totalItems) {
            // Reached the cloned end, reset to the original 3 items
            track.style.transition = 'none';  // Disable transition temporarily
            currentIndex = 0;  // Reset index
            track.style.transform = `translateX(${-itemWidth * 3}px)`;  // Jump back to original items

            // Re-enable the transition after the jump
            setTimeout(() => track.style.transition = 'transform 0.5s ease-in-out', 50);
        }
    }

    // Auto-slide every 3 seconds
    function startCarousel() {
        intervalId = setInterval(slideNext, 3000);
    }

    function stopCarousel() {
        clearInterval(intervalId);
    }

    // Handle visibility change
    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') {
            // Tab is active again, resume carousel and ensure position is correct
            track.style.transition = 'none';  // Temporarily disable transition
            track.style.transform = `translateX(${-itemWidth * (currentIndex + 3)}px)`;  // Correct position
            setTimeout(() => track.style.transition = 'transform 0.5s ease-in-out', 50);  // Re-enable transition
            startCarousel();  // Resume sliding
        } else {
            stopCarousel();  // Stop sliding when tab is inactive
        }
    });

    // Start the carousel initially
    startCarousel();

} catch (error) {
    console.error('Error:', error);
}

