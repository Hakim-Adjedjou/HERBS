<?php
try {
    // Open the SQLite database connection
    $db = new PDO('sqlite:' . __DIR__ . '/database.db');
    // Set error mode to exceptions
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Print success message
    //echo "Connected successfully to the SQLite database.";
} catch (Exception $e) {
   // echo "Unable to connect: " . $e->getMessage();
    exit;
}
?>

