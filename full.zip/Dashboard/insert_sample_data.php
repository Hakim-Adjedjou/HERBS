<?php
global $db;
require 'db.php';

// Sample data for registrations (different values for each entry)
$db->exec("INSERT INTO registrations (first_name, last_name, address, phone, email) VALUES
    ('Alice', 'Brown', '101 First Ave', '+1 123 456 789', 'alice.brown@example.com'),
    ('David', 'Smith', '202 Second St', '+1 234 567 890', 'david.smith@example.com'),
    ('Emma', 'Johnson', '303 Third Blvd', '+1 345 678 901', 'emma.johnson@example.com'),
    ('Liam', 'Davis', '404 Fourth Ave', '+1 456 789 012', 'liam.davis@example.com'),
    ('Olivia', 'Lee', '505 Fifth Rd', '+1 567 890 123', 'olivia.lee@example.com'),
    ('Noah', 'White', '606 Sixth St', '+1 678 901 234', 'noah.white@example.com'),
    ('Sophia', 'Miller', '707 Seventh Ln', '+1 789 012 345', 'sophia.miller@example.com')");

// Sample data for archives (different names, addresses, phone numbers, and decisions)
$db->exec("INSERT INTO archives (first_name, last_name, address, phone, email, decision, decision_date) VALUES
    ('Henry', 'Taylor', '111 Sunset Blvd', '+1 987 654 321', 'henry.taylor@example.com', 'Approved', '2025-02-01'),
    ('Isabella', 'Harris', '222 Maple St', '+1 876 543 210', 'isabella.harris@example.com', 'Pending', '2025-02-02'),
    ('William', 'Martinez', '333 Oak Ave', '+1 765 432 109', 'william.martinez@example.com', 'Rejected', '2025-02-03'),
    ('Mia', 'Clark', '444 Birch Rd', '+1 654 321 098', 'mia.clark@example.com', 'Approved', '2025-02-04'),
    ('James', 'Garcia', '555 Pine St', '+1 543 210 987', 'james.garcia@example.com', 'Pending', '2025-02-05'),
    ('Charlotte', 'Rodriguez', '666 Willow Dr', '+1 432 109 876', 'charlotte.rodriguez@example.com', 'Approved', '2025-02-06'),
    ('Elijah', 'Lopez', '777 Cedar Ave', '+1 321 098 765', 'elijah.lopez@example.com', 'Pending', '2025-02-07')");

// Sample data for members (different values with corresponding emails and join dates)
$db->exec("INSERT INTO members (first_name, last_name, adresse, phone, email, joining_date) VALUES
    ('Aiden', 'Walker', '12 Park Ave', '+1 111 222 333', 'aiden.walker@example.com', '2024-10-01'),
    ('Ella', 'Young', '24 Rose Blvd', '+1 222 333 444', 'ella.young@example.com', '2024-10-02'),
    ('Michael', 'Scott', '36 River Rd', '+1 333 444 555', 'michael.scott@example.com', '2024-10-03'),
    ('Harper', 'Adams', '48 Ocean St', '+1 444 555 666', 'harper.adams@example.com', '2024-10-04'),
    ('Lucas', 'Baker', '60 Hill Rd', '+1 555 666 777', 'lucas.baker@example.com', '2024-10-05'),
    ('Ava', 'Carter', '72 Forest Ln', '+1 666 777 888', 'ava.carter@example.com', '2024-10-06'),
    ('Mason', 'Phillips', '84 Valley Dr', '+1 777 888 999', 'mason.phillips@example.com', '2024-10-07')");

//echo "Sample data inserted successfully!";
?>
