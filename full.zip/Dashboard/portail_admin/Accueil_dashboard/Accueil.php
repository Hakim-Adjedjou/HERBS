<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../Connexion/login.html');
    exit;
}
global $db;
require '../db.php';

// Fetch the total number of members
$totalMembers = $db->query("SELECT COUNT(*) AS total FROM members")->fetch(PDO::FETCH_ASSOC)['total'];

// Fetch monthly member counts
$monthlyData = $db->query("
    SELECT strftime('%Y-%m', joining_date) as month, COUNT(*) as members_count
    FROM members
    GROUP BY month
    ORDER BY month ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Accueil</title>
    <link rel="stylesheet" href="accueil_style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<div class="dashboard-container">
    <!-- Side Navigation -->
    <nav class="sidebar">
        <h2>Admin Dashboard</h2>
        <ul>
            <li><a href="#"><span class="material-icons">insights</span> Accueil</a></li>
            <li><a href="../Demande_inscription/Demande_inscription.php"><span class="material-icons">pending_actions</span> Demande d'inscription</a></li>
            <li><a href="../Dons_cotisations/Dons_cotisations.php"><span class="material-icons">volunteer_activism</span> Cotisation et dons</a></li>
            <li><a href="../../Membres%20inscrits/membres.php"><span class="material-icons">people</span> Membres inscrits</a></li>
            <li><a href="../Archives/Archives.php"><span class="material-icons">archive</span> Archives</a></li>
            <li><a href="../../Connexion/logout.php"><span class="material-icons">logout</span> Logout</a></li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <h2>Accueil</h2>

        <div class="card-container">
            <!-- Total Members Card -->
            <div class="card">
                <h3>Total Members</h3>
                <p><?= $totalMembers ?></p>
            </div>
        </div>

        <!-- Chart Section -->
        <div>
            <canvas id="membersChart" width="800" height="400"></canvas>
        </div>
    </div>
</div>

<script>
    // Prepare data for the chart
    const chartLabels = <?= json_encode(array_column($monthlyData, 'month')) ?>;
    const chartData = <?= json_encode(array_column($monthlyData, 'members_count')) ?>;

    // Create the chart
    const ctx = document.getElementById('membersChart').getContext('2d');
    const membersChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartLabels,
            datasets: [{
                label: 'New Members Per Month',
                data: chartData,
                borderColor: 'rgba(54, 162, 235, 1)',
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderWidth: 2,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
</script>

</body>
</html>
