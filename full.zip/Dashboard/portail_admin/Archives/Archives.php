<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../Connexion/login.html');
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Archives</title>
    <link rel="stylesheet" href="archives_style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>

<?php
/** @var PDO $db */
global $db;
require __DIR__ . '/../../db.php';
$archives = $db->query("SELECT * FROM archives")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="dashboard-container">
    <!-- Side Navigation -->
    <nav class="sidebar">
        <h2>Tableau de bord</h2>
        <ul>
            <li><a href="../Accueil_dashboard/Accueil.php">
                    <span class="material-icons">insights</span> Accueil</a>
            </li>
            <li><a href="../Demande_inscription/Demande_inscription.php">
                    <span class="material-icons">pending_actions</span> Demande d'inscription</a>
            </li>
            <li><a href="../Dons_cotisations/Dons_cotisations.php">
                    <span class="material-icons">volunteer_activism</span> Cotisation et dons</a>
            </li>
            <li><a href="../Membres%20inscrits/membres.php">
                    <span class="material-icons">people</span> Membres inscrits</a>
            </li>
            <li><a href="#">
                    <span class="material-icons">archive</span> Archives</a>
            </li>
            <li><a href="../../Connexion/logout.php" id="logout-link">
                    <span class="material-icons">logout</span> Déconnexion</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Tables -->
        <section>
            <h2>Archives</h2>
            <!-- Search Bar -->
            <div class="search-bar">
                <input type="text" id="search-input" placeholder="Rechercher un membre...">
            </div>
            <table id="archives-table">
                <thead>
                <tr>
                    <th class="select-column" style="display: none;">Select</th>
                    <th>Prénom</th>
                    <th>Nom</th>
                    <th>Adresse</th>
                    <th>Téléphone</th>
                    <th>Décision</th>
                    <th>Date Décision</th>
                </tr>
                </thead>
                <tbody>
                <?php if (empty($archives)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 20px; font-style: italic; color: #666;">
                            Pas d'archives pour l'instant!
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($archives as $archive): ?>
                        <tr>
                            <td class="select-column" style="display: none;"><input type="checkbox" class="member-checkbox" data-id="<?= $archive['id'] ?>"></td>
                            <td><?= htmlspecialchars($archive['first_name']) ?></td>
                            <td><?= htmlspecialchars($archive['last_name']) ?></td>
                            <td><?= htmlspecialchars($archive['address']) ?></td>
                            <td><?= htmlspecialchars($archive['phone']) ?></td>
                            <td><?= htmlspecialchars($archive['decision']) ?></td>
                            <td><?= htmlspecialchars($archive['decision_date']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>

            <!-- Buttons -->
            <div id="initial-buttons" class="button-group">
                <button id="download-csv">Télécharger</button>
                <button id="print-table">Imprimer</button>
                <button id="supprimer-btn">Supprimer</button>
            </div>

            <div id="delete-buttons" class="button-group" style="display: none;">
                <button id="confirm-delete" style="background-color: #FF4C4C;">Confirmer</button>
                <button id="select-all-btn">Sélectionner tout</button>
                <button id="cancel-btn">Annuler</button>
            </div>
        </section>
    </div>
</div>

<script src="gestion_archives.js"></script>
</body>
</html>
