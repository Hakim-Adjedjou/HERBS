<?php
header('Content-Type: application/json');
global $db;
require __DIR__ . '/../../db.php'; // Ensure the correct path to your db.php file

try {
    // Get the JSON data sent from the client
    $input = json_decode(file_get_contents('php://input'), true);

    if (!isset($input['archive_ids']) || empty($input['archive_ids'])) {
        echo json_encode(['success' => false, 'message' => 'Aucune archive sélectionnée pour la suppression.']);
        exit;
    }

    $archiveIds = $input['archive_ids'];

    // Prepare the DELETE statement
    $placeholders = implode(',', array_fill(0, count($archiveIds), '?'));
    $stmt = $db->prepare("DELETE FROM archives WHERE id IN ($placeholders)");

    // Execute the deletion with the provided IDs
    if ($stmt->execute($archiveIds)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Échec de la suppression des archives.']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Une erreur est survenue :' . $e->getMessage()]);
}

