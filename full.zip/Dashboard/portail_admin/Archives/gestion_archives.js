// JavaScript to filter table rows based on search input
document.getElementById('search-input').addEventListener('input', function () {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#registration-table tbody tr');

    rows.forEach(row => {
        const rowText = row.textContent.toLowerCase();
        if (rowText.includes(filter)) {
            row.style.display = '';  // Show row
        } else {
            row.style.display = 'none';  // Hide row
        }
    });
});

// Download table as CSV
document.getElementById('download-csv').addEventListener('click', function () {
    let csvContent = "data:text/csv;charset=utf-8,";

    const rows = document.querySelectorAll('#registration-table tr');

    rows.forEach(row => {
        const columns = Array.from(row.querySelectorAll('th, td')).filter((col, index) => index !== 0);  // Skip select column

        const rowData = columns.map(column => `"${column.textContent.trim().replace(/"/g, '""')}"`).join(",");
        csvContent += rowData + "\r\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'archives.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
});

// Print the table
document.getElementById('print-table').addEventListener('click', function () {
    const tableContent = document.getElementById('registration-table').outerHTML;

    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Table des archives</title>');
    printWindow.document.write('<style>th:first-child, td:first-child { display: none; } table { width: 100%; border-collapse: collapse; } th, td { padding: 8px; border: 1px solid black; }</style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<h2>Table des archives</h2>');
    printWindow.document.write(tableContent);
    printWindow.document.write('</body></html>');

    printWindow.document.close();
    printWindow.print();
    printWindow.close();
});

// Handle delete logic
// (This remains similar to the delete logic you had previously)
const supprimerBtn = document.getElementById('supprimer-btn');
const selectAllBtn = document.getElementById('select-all-btn');
const cancelBtn = document.getElementById('cancel-btn');
const confirmDeleteBtn = document.getElementById('confirm-delete');
const checkboxes = document.querySelectorAll('.member-checkbox');
const selectColumns = document.querySelectorAll('.select-column');
const initialButtons = document.getElementById('initial-buttons');
const deleteButtons = document.getElementById('delete-buttons');
const tableBody = document.querySelector('#registration-table tbody');

let isDeleteMode = false;

supprimerBtn.addEventListener('click', () => {
    const rows = document.querySelectorAll('#archives-table tbody tr');

    // Check if the table has any rows
    if (rows.length === 0 || (rows.length === 1 && rows[0].textContent.includes('Pas d\'archives'))) {
        alert('Le tableau est vide. Il n’y a aucun membre à supprimer.');
        return;
    }

    if (!isDeleteMode) {
        // Enter selection mode
        initialButtons.classList.add('hidden');
        setTimeout(() => {
            initialButtons.style.display = 'none';
            deleteButtons.style.display = 'flex';
            deleteButtons.classList.remove('hidden');
        }, 500);

        selectColumns.forEach(col => col.style.display = 'table-cell');  // Show select column
        isDeleteMode = true;
    }
});


selectAllBtn.addEventListener('click', () => {
    checkboxes.forEach(checkbox => checkbox.checked = true);
});

cancelBtn.addEventListener('click', () => {
    resetSelectionMode();
});

confirmDeleteBtn.addEventListener('click', () => {
    const selectedCheckboxes = document.querySelectorAll('.member-checkbox:checked');

    if (selectedCheckboxes.length === 0) {
        alert('Veuillez sélectionner au moins une archive à supprimer.');
        return;
    }

    const archiveIds = Array.from(selectedCheckboxes).map(checkbox => checkbox.getAttribute('data-id'));

    fetch('delete_archives.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archive_ids: archiveIds }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Les archives sélectionnées ont été supprimées avec succès !');
                selectedCheckboxes.forEach(checkbox => checkbox.closest('tr').remove());
                if (tableBody.children.length === 0) displayNoArchivesMessage();
                resetSelectionMode();
            } else alert('Échec de la suppression des archives : ' + data.message);
        })
        .catch(error => console.error('Error:', error));
});

function resetSelectionMode() {
    checkboxes.forEach(checkbox => checkbox.checked = false);
    selectColumns.forEach(col => col.style.display = 'none');
    deleteButtons.classList.add('hidden');
    setTimeout(() => {
        deleteButtons.style.display = 'none';
        initialButtons.style.display = 'flex';
        initialButtons.classList.remove('hidden');
    }, 500);
    isDeleteMode = false;
}

function displayNoArchivesMessage() {
    const noArchivesRow = document.createElement('tr');
    noArchivesRow.innerHTML = '<td colspan="7" style="text-align: center; padding: 20px; font-style: italic; color: #666;">Pas d\'archives pour l\'instant!</td>';
    tableBody.appendChild(noArchivesRow);
}
