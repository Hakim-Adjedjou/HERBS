<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../Connexion/login.html');
    exit;
}
#echo $_SESSION['logged_in'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demandes d'inscription en cours</title>
    <link rel="stylesheet" href="style_inscription.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>

<?php
/** @var PDO $db */
global $db;
require __DIR__ . '/../../db.php';

$registrations = $db->query("SELECT * FROM registrations")->fetchAll(PDO::FETCH_ASSOC);
?>


<div class="dashboard-container">
    <!-- Side Navigation -->
    <nav class="sidebar">
        <h2>Tableau de bord</h2>
        <ul>
            <li><a href="../Accueil_dashboard/Accueil.php">
                    <span class="material-icons">insights</span> Accueil </a></li>
            <li><a href="#">
                <span class="material-icons">pending_actions</span> Demandes d'inscription </a></li>
            <li><a href="../Dons_cotisations/Dons_cotisations.php">
                    <span class="material-icons">volunteer_activism</span> Cotisation et dons </a></li>
            <li><a href="../Membres%20inscrits/membres.php">
                    <span class="material-icons">people</span> Membres inscrits </a></li>
            <li><a href="../Archives/Archives.php">
                    <span class="material-icons">archive</span> Archives </a></li>
            <li><a href="../../Connexion/logout.php" id="logout-link">
                    <span class="material-icons">logout</span> Déconnexion</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Tables -->
        <section>
            <h2>Demandes d'inscription en cours</h2>
            <table id="registration-table">
                <thead>
                <tr>
                    <th>Prénom</th>
                    <th>Nom</th>
                    <th>Adresse</th>
                    <th>Téléphone</th>
                    <th>email</th>
                    <th>Décision</th>
                </tr>
                </thead>
                <tbody>
                <?php if (empty($registrations)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 20px; font-style: italic; color: #666;">
                            Pas de demande d'inscription pour le moment!
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($registrations as $registration): ?>
                        <tr>
                            <td><?= htmlspecialchars($registration['first_name']) ?></td>
                            <td><?= htmlspecialchars($registration['last_name']) ?></td>
                            <td><?= htmlspecialchars($registration['address']) ?></td>
                            <td><?= htmlspecialchars($registration['phone']) ?></td>
                            <td><?= htmlspecialchars($registration['email']) ?></td>
                            <td>
                                <button class="approve-btn" data-id="<?= $registration['id'] ?>">Accepter</button>
                                <button class="decline-btn" data-id="<?= $registration['id'] ?>">Refuser</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </section>
    </div>
</div>

<script src="gestion_decision.js"></script>
</body>
</html>