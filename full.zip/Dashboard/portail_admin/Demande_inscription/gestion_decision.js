document.querySelectorAll('.approve-btn, .decline-btn').forEach(button => {
    button.addEventListener('click', function () {
        const row = this.closest('tr');
        const id = this.getAttribute('data-id');
        const decision = this.textContent.trim();  // Get the button's text content ("Approve" or "Decline")
        const decisionDate = new Date().toISOString();  // Get current date and time in ISO format

        // Send the decision to the server via fetch
        fetch('process_registration.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id, decision, decisionDate }),
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Smooth transition effect before removal
                    row.style.transition = 'opacity 1s';
                    row.style.opacity = 0;

                    setTimeout(() => {
                        row.remove();  // Remove row after transition
                        // Check if the table is now empty and display the message
                        const tableBody = document.querySelector('#registration-table tbody');
                        if (tableBody.children.length === 0) {
                            const noRequestsRow = document.createElement('tr');
                            noRequestsRow.innerHTML = `
                                <td colspan="6" style="text-align: center; padding: 20px; font-style: italic; color: #666;">
                                     Pas de demande d'inscription pour le moment!
                                </td>
                            `;
                            tableBody.appendChild(noRequestsRow);
                        }
                    }, 1000);
                } else {
                    console.error('Server Error:', data.message);  // Log the message from the server
                    alert('Erreur lors du traitement de la demande. Veuillez réessayer.');
                }
            })
            .catch(error => console.error('Network or JSON error:', error));
    });
});
