<?php
global $db;
require __DIR__ . '/../../db.php';

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'];
$decision = strtolower($data['decision']);  // Normalize decision text
$decisionDate = $data['decisionDate'];

if ($id && $decision && $decisionDate) {
    try {
        // Get registration details
        $stmt = $db->prepare("SELECT * FROM registrations WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $registration = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($registration) {
            if ($decision === 'accepter') {
                // Insert into members table
                $memberStmt = $db->prepare(
                    "INSERT INTO members (first_name, last_name, adresse, phone, email, joining_date)
                     VALUES (:first_name, :last_name, :adresse, :phone, :email, :joining_date)"
                );
                $memberStmt->execute([
                    ':first_name' => $registration['first_name'],
                    ':last_name' => $registration['last_name'],
                    ':adresse' => $registration['address'],
                    ':phone' => $registration['phone'],
                    ':email'=> $registration['email'],
                    ':joining_date' => date('Y-m-d', strtotime($decisionDate))

                ]);
            } elseif ($decision === 'refuser') {
                // Insert into archives table
                $archiveStmt = $db->prepare(
                    "INSERT INTO archives (first_name, last_name, address, phone, email, decision, decision_date)
                     VALUES (:first_name, :last_name, :address, :phone, :email, 'refus', :decision_date)"
                );
                $archiveStmt->execute([
                    ':first_name' => $registration['first_name'],
                    ':last_name' => $registration['last_name'],
                    ':address' => $registration['address'],
                    ':phone' => $registration['phone'],
                    ':email'=> $registration['email'],
                    ':decision_date' => date('Y-m-d', strtotime($decisionDate))

                ]);
            }

            // Delete from registrations
            $deleteStmt = $db->prepare("DELETE FROM registrations WHERE id = :id");
            $deleteStmt->bindParam(':id', $id);
            $deleteStmt->execute();

            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Inscription non trouvée']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
}
