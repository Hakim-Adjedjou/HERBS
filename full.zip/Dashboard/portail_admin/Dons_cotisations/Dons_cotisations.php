<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../styles.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>

<?php
/** @var PDO $db */
global $db;
require __DIR__ . '/../../db.php';
$donations = $db->query("SELECT * FROM donations")->fetchAll(PDO::FETCH_ASSOC);
?>



<div class="dashboard-container">
    <!-- Side Navigation -->
    <nav class="sidebar">
        <h2>Admin Dashboard</h2>
        <ul>
            <li><a href="../Accueil_dashboard/Accueil.php">
                    <span class="material-icons">pending_actions</span> Accueil</li>
            </a>
            <li><a href="../Demande_inscription/Demande_inscription.php">
                    <span class="material-icons">pending_actions</span> Demande d'inscription</li>
            </a>
            <li><a href="#">
                    <span class="material-icons">volunteer_activism</span> Cotisation et dons</li>
            </a>
            <li><a href="../Membres%20inscrits/membres.php">
                    <span class="material-icons">people</span> Membres inscrits</li>
            </a>
            <li><a href="../Archives/Archives.php">
                    <span class="material-icons">archive</span> Archives</li>
            </a>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <section>
            <h2>Cotisation et dons</h2>
            <table id="donations-table">
                <thead>
                <tr>
                    <th>Member Name</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Payment Date</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($donations as $donation): ?>
                <tr>
                    <td><?= htmlspecialchars($donation['member_name']) ?></td>
                    <td>&euro;<?= htmlspecialchars($donation['amount']) ?></td>
                    <td><?= htmlspecialchars($donation['status']) ?></td>
                    <td><?= htmlspecialchars($donation['payment_date']) ?></td>
                    <td><button class="edit-btn" data-id="<?= $donation['id'] ?>">Edit</button></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
</div>

<script src="script.js"></script>
</body>
</html>