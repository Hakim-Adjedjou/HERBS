<?php
global $db;
require __DIR__ . '/../../db.php';
header('Content-Type: application/json');

try {
    // Get form data
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $adresse = $_POST['adresse'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $joining_date = $_POST['joining_date'];

    // Insert new member
    $stmt = $db->prepare(
        "INSERT INTO members (first_name, last_name, adresse, email, phone, joining_date) 
         VALUES (:first_name, :last_name, :adresse, :email, :phone, :joining_date)"
    );
    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':adresse', $adresse);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':joining_date', $joining_date);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'new_member_id' => $db->lastInsertId()]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>

