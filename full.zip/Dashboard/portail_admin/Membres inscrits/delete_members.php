<?php
global $db;
require __DIR__ . '/../../db.php';
header('Content-Type: application/json');

try {
    // Get the member IDs from the POST request
    $data = json_decode(file_get_contents('php://input'), true);
    $memberIds = $data['member_ids'];

    if (empty($memberIds)) {
        echo json_encode(['success' => false, 'message' => 'No members selected']);
        exit;
    }

    // Fetch details of members to be archived
    $placeholders = implode(',', array_fill(0, count($memberIds), '?'));
    $stmt = $db->prepare("SELECT * FROM members WHERE id IN ($placeholders)");
    $stmt->execute($memberIds);
    $membersToArchive = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Insert members into archives table
    $archiveStmt = $db->prepare(
        "INSERT INTO archives (first_name, last_name, address, phone, email, decision, decision_date) 
         VALUES (:first_name, :last_name, :adresse, :phone, :email, 'Suppression', :decision_date)"
    );

    $currentDate = date('Y-m-d');  // Current date for the decision_date
    foreach ($membersToArchive as $member) {
        $archiveStmt->execute([
            ':first_name' => $member['first_name'],
            ':last_name' => $member['last_name'],
            ':adresse' => $member['adresse'],
            ':phone' => $member['phone'],
            ':email' => $member['email'],
            ':decision_date' => $currentDate,
        ]);
    }

    // Delete members from the members table
    $deleteStmt = $db->prepare("DELETE FROM members WHERE id IN ($placeholders)");
    $deleteStmt->execute($memberIds);

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>

