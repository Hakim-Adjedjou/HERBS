// JavaScript to filter table rows based on search input
document.getElementById('search-input').addEventListener('input', function () {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#members-table tbody tr');

    rows.forEach(row => {
        const rowText = row.textContent.toLowerCase();
        if (rowText.includes(filter)) {
            row.style.display = '';  // Show row
        } else {
            row.style.display = 'none';  // Hide row
        }
    });
});



document.querySelectorAll('.edit-btn').forEach(button => {
    button.addEventListener('click', function () {
        const row = this.closest('tr');
        const id = this.getAttribute('data-id');

        // Get all the editable cells (excluding the last column with the Edit button)
        const cells = row.querySelectorAll('td:not(:last-child)');
        const originalData = {};

        // Store original data in case of cancellation
        cells.forEach((cell, index) => {
            originalData[index] = cell.textContent.trim();
            cell.contentEditable = 'true';
            cell.style.backgroundColor = '#f0f8ff';  // Light background to indicate edit mode
        });

        // Replace the Edit button with Save and Cancel buttons
        this.style.display = 'none';  // Hide Edit button
        const saveButton = document.createElement('button');
        saveButton.textContent = 'Save';
        saveButton.classList.add('save-btn');

        const cancelButton = document.createElement('button');
        cancelButton.textContent = 'Cancel';
        cancelButton.classList.add('cancel-btn');

        // Insert Save and Cancel buttons in the row
        const actionsCell = row.querySelector('td:last-child');
        actionsCell.appendChild(saveButton);
        actionsCell.appendChild(cancelButton);

        saveButton.addEventListener('click', function () {
            const updatedData = {};
            let hasError = false;

            // Select all editable cells but exclude the hidden select column
            const editableCells = row.querySelectorAll('td:not(:last-child):not(.select-column)');

            editableCells.forEach((cell, index) => {
                    const value = cell.textContent.replace(/\s+/g, ' ').trim();  // Clean spaces

                    // Mandatory field checks and pattern validation
                    if (index === 0 && (!value || !isValidName(value))) {
                        alert('Le prénom est invalide. Il ne doit pas contenir de chiffres ni de caractères spéciaux.');
                        cell.style.border = '2px solid red';
                        hasError = true;
                    } else if (index === 1 && (!value || !isValidName(value))) {
                        alert('Le nom est invalide. Il ne doit pas contenir de chiffres ni de caractères spéciaux.');
                        cell.style.border = '2px solid red';
                        hasError = true;
                    } else if (index === 2 && !value) {
                        alert('Adresse ne peut pas être vide');
                        cell.style.border = '2px solid red';
                        hasError = true;
                    }else if (index === 3 && (!value || !isValidEmail(value))) {
                        alert('L\'adresse email est invalide. Veuillez entrer une adresse correcte.');
                        cell.style.border = '2px solid red';
                        hasError = true;
                    } else if (index === 4 && (!value ||!isValidPhoneNumber(value))) {
                        alert('Le numéro de téléphone est invalide. Il doit commencer par "+" (facultatif) et contenir uniquement des chiffres et des espaces.');
                        cell.style.border = '2px solid red';
                        hasError = true;
                    } else if (index === 5 && (!value ||!isValidDate(value)) ) {
                        alert('La date d\'inscription est invalide. Veuillez entrer une date au format AAAA-MM-JJ.');
                        cell.style.border = '2px solid red';
                        hasError = true;
                    } else {
                        cell.style.border = '';  // Clear errors if valid
                    }

                    updatedData[index] = value;  // Store validated content
                });


                if (hasError) return;  // Prevent submission on errors

            // Send the updated data to the backend
            fetch('update_member.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: id,
                    first_name: updatedData[0],
                    last_name: updatedData[1],
                    adresse: updatedData[2],
                    email: updatedData[3],
                    phone: updatedData[4],
                    joining_date: updatedData[5]
                }),
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Mise à jour avec succés!');
                    } else {
                        alert('Echec de la mise à jour : ' + data.message);
                    }
                })
                .catch(error => console.error('Error:', error));

            // Disable editing and restore styles
            editableCells.forEach(cell => {
                cell.contentEditable = 'false';
                cell.style.backgroundColor = '';
            });

            // Restore the Edit button and remove Save/Cancel buttons
            saveButton.remove();
            cancelButton.remove();
            button.style.display = '';
        });



        // Cancel button functionality
        cancelButton.addEventListener('click', function () {
            // Restore original content and disable editing
            cells.forEach((cell, index) => {
                cell.textContent = originalData[index];
                cell.contentEditable = 'false';
                cell.style.backgroundColor = '';
            });

            // Restore Edit button and remove Save/Cancel buttons
            saveButton.remove();
            cancelButton.remove();
            button.style.display = '';
        });
    });
});

// Download table as CSV
document.getElementById('download-csv').addEventListener('click', function () {
    let csvContent = "data:text/csv;charset=utf-8,";

    // Get table rows
    const rows = document.querySelectorAll('#members-table tr');

    rows.forEach(row => {
        const columns = Array.from(row.querySelectorAll('th, td'));

        // Remove the last column (Actions button)
        const rowData = columns.slice(0, -1).map(column => `"${column.textContent.trim().replace(/"/g, '""')}"`).join(",");

        csvContent += rowData + "\r\n";
    });

    // Create a download link and trigger download
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'members.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
});

// Print the table
document.getElementById('print-table').addEventListener('click', function () {
    const tableContent = document.getElementById('members-table').outerHTML;

    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Table des membres inscrits</title>');
    printWindow.document.write('<style>th:last-child, td:last-child { display: none; }');  // Hide Actions column
    printWindow.document.write('table { width: 100%; border-collapse: collapse; } th, td { padding: 8px; border: 1px solid black; }</style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write('<h2>Table des membres inscrits</h2>');
    printWindow.document.write(tableContent);
    printWindow.document.write('</body></html>');

    printWindow.document.close();
    printWindow.print();

    // Automatically close the tab after printing
    printWindow.close();
});


// Show the form when "Ajouter un Membre" is clicked
document.getElementById('add-member-btn').addEventListener('click', function () {
    document.getElementById('add-member-form').style.display = 'block';
});

// Hide the form and reset all fields when "Cancel" is clicked
document.getElementById('cancel-new-member').addEventListener('click', function () {
    const form = document.getElementById('new-member-form');
    form.reset();  // Clear all fields
    document.getElementById('add-member-form').style.display = 'none';  // Hide the form
});


// Handle form submission using AJAX
document.getElementById('new-member-form').addEventListener('submit', function (e) {
    e.preventDefault();  // Prevent the default form submission

    // Get form data
    const formData = new FormData(this);

    // Perform validation before sending data
    if (!validateNewMemberForm(formData)) {
        return;  // Stop the submission if validation fails
    }

    // Send data to the server using fetch
    fetch('add_member.php', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Ajout avec succés!');

                const table = document.querySelector('#members-table tbody');

                // Remove the "No members for now!" message if it exists
                const noMembersRow = document.querySelector('#members-table tbody tr td[colspan="8"]');
                if (noMembersRow) {
                    noMembersRow.parentElement.remove();
                }

                const newRow = document.createElement('tr');
                newRow.innerHTML = `
                        <td class="select-column" style="display: ${isDeleteMode ? 'table-cell' : 'none'};">
                            <input type="checkbox" class="member-checkbox" data-id="${data.new_member_id}">
                        </td>
                        <td>${formData.get('first_name')}</td>
                        <td>${formData.get('last_name')}</td>
                        <td>${formData.get('adresse')}</td>
                        <td>${formData.get('email')}</td>
                        <td>${formData.get('phone')}</td>
                        <td>${formData.get('joining_date')}</td>
                        <td>
                            <button class="edit-btn" data-id="${data.new_member_id}">Edit</button>
                        </td>
                    `;

// Append the new row and update event listeners if necessary
                table.appendChild(newRow);

                // Hide the form and reset it
                document.getElementById('add-member-form').style.display = 'none';
                document.getElementById('new-member-form').reset();
            } else {
                alert('Echec de l\'ajout: ' + data.message);
            }
        })
        .catch(error => console.error('Error:', error));
});

const supprimerBtn = document.getElementById('supprimer-btn');
const selectAllBtn = document.getElementById('select-all-btn');
const cancelBtn = document.getElementById('cancel-btn');
const confirmDeleteBtn = document.getElementById('confirm-delete');
const checkboxes = document.querySelectorAll('.member-checkbox');
const selectColumns = document.querySelectorAll('.select-column');
const initialButtons = document.getElementById('initial-buttons');
const deleteButtons = document.getElementById('delete-buttons');
const tableBody = document.querySelector('#members-table tbody');

// Toggle visibility of select column and buttons when "Supprimer" is clicked
let isDeleteMode = false;

supprimerBtn.addEventListener('click', () => {
    const rows = document.querySelectorAll('#members-table tbody tr');


    // Check if the table has any rows
    if (rows.length === 0 || (rows.length === 1 && rows[0].textContent.includes('Pas de membres'))) {
        alert('Le tableau est vide. Il n’y a aucun membre à supprimer.');
        return;
    }

    if (!isDeleteMode) {
        // Enter selection mode
        initialButtons.classList.add('hidden');
        setTimeout(() => {
            initialButtons.style.display = 'none';
            deleteButtons.style.display = 'flex';
            deleteButtons.classList.remove('hidden');
        }, 500);

        selectColumns.forEach(col => col.style.display = 'table-cell');  // Show select column
        isDeleteMode = true;
    }
});

// Handle "Sélectionner tout" button
selectAllBtn.addEventListener('click', () => {
    checkboxes.forEach(checkbox => checkbox.checked = true);  // Check all checkboxes
});

// Handle "Annuler" button to reset to initial state
cancelBtn.addEventListener('click', () => {
    resetSelectionMode();
});

// Handle "Confirm Delete" button
confirmDeleteBtn.addEventListener('click', () => {
    const selectedCheckboxes = document.querySelectorAll('.member-checkbox:checked');

    if (selectedCheckboxes.length === 0) {
        alert('Veuillez sélectionner au moins un membre a supprimer.');
        return;
    }

    // Collect selected member IDs
    const memberIds = Array.from(selectedCheckboxes).map(checkbox => checkbox.getAttribute('data-id'));

    // Send selected IDs to the server for deletion
    fetch('delete_members.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ member_ids: memberIds }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('succés de la suppresion des membres sélectionnés!');

                // Remove the rows of the deleted members
                selectedCheckboxes.forEach(checkbox => {
                    const row = checkbox.closest('tr');
                    row.remove();
                });

                // Check if the table is now empty
                if (tableBody.children.length === 0) {
                    displayNoMembersMessage();
                }

                resetSelectionMode();
            } else {
                alert('Echec de la supression des membres: ' + data.message);
            }
        })
        .catch(error => console.error('Error:', error));
});

// Function to reset the selection mode
function resetSelectionMode() {
    checkboxes.forEach(checkbox => checkbox.checked = false);  // Uncheck all checkboxes
    selectColumns.forEach(col => col.style.display = 'none');  // Hide select column

    deleteButtons.classList.add('hidden');  // Hide delete buttons smoothly
    setTimeout(() => {
        deleteButtons.style.display = 'none';
        initialButtons.style.display = 'flex';  // Show initial buttons again
        initialButtons.classList.remove('hidden');
    }, 500);

    isDeleteMode = false;
}

// Function to display the "No members for now!" message
function displayNoMembersMessage() {
    const noMembersRow = document.createElement('tr');
    noMembersRow.innerHTML = `
        <td colspan="8" style="text-align: center; padding: 20px;">Pas de membres pour l'instant!</td>
    `;
    tableBody.appendChild(noMembersRow);
}

function isValidDate(dateString) {
    // Regular expression to match YYYY-MM-DD format
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;

    if (!dateRegex.test(dateString)) {
        return false;  // Format is incorrect
    }

    // Check if the date is valid using the Date object
    const date = new Date(dateString);
    const year = date.getFullYear();
    const month = date.getMonth() + 1;  // Months are 0-based in JS
    const day = date.getDate();

    // Split the input date string to compare exact values
    const [inputYear, inputMonth, inputDay] = dateString.split('-').map(Number);

    // Ensure the parsed date matches the input values to avoid issues like 2023-02-30
    return (
        year === inputYear &&
        month === inputMonth &&
        day === inputDay
    );
}

function isValidPhoneNumber(phoneNumber) {
    // Regular expression to match:
    // - Optional '+' at the beginning
    // - Followed by digits and spaces only
    const phoneRegex = /^\+?[0-9\s]+$/;
    return phoneRegex.test(phoneNumber);
}

function isValidName(name) {
        // Regular expression to match names containing letters, spaces, hyphens, and apostrophes
        const nameRegex = /^[a-zA-ZÀ-ÿ' -]+$/;
        return nameRegex.test(name);
}

function isValidEmail(email) {
    // Regular expression to validate email format
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
}


function validateNewMemberForm(formData) {
    const firstName = formData.get('first_name').trim();
    const lastName = formData.get('last_name').trim();
    const adresse = formData.get('adresse').trim();
    const email = formData.get('email').trim();
    const phone = formData.get('phone').trim();
    const joiningDate = formData.get('joining_date').trim();


    if (!firstName || !isValidName(firstName)) {
        alert('Le prénom est invalide. Il ne doit pas être vide ni contenir de chiffres ou de caractères spéciaux.');
        return false;
    }

    if (!lastName || !isValidName(lastName)) {
        alert('Le nom est invalide. Il ne doit pas être vide ni contenir de chiffres ou de caractères spéciaux.');
        return false;
    }

    if (!adresse) {
        alert('L\'adresse ne peut pas être vide.');
        return false;
    }

    if (!email || !isValidEmail(email)) {
        alert('L\'adresse email est invalide. Veuillez entrer une adresse correcte.');
        return false;
    }

    if (!phone || !isValidPhoneNumber(phone)) {
        alert('Le numéro de téléphone est invalide. Il doit commencer par "+" (facultatif) et contenir uniquement des chiffres et des espaces.');
        return false;
    }

    if (!joiningDate || !isValidDate(joiningDate)) {
        alert('La date d\'inscription est invalide. Veuillez entrer une date au format AAAA-MM-JJ.');
        return false;
    }

    return true;  // All validations passed
}






