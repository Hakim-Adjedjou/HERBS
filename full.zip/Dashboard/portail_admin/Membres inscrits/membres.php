<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: ../Connexion/login.html');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Membres inscrits</title>
    <link rel="stylesheet" href="membres_style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>

<?php
/** @var PDO $db */
global $db;
require __DIR__ . '/../../db.php';
$members = $db->query("SELECT * FROM members")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="dashboard-container">
    <!-- Side Navigation -->
    <nav class="sidebar">
        <h2>Tableau de bord</h2>
        <ul>
            <li><a href="../Accueil_dashboard/Accueil.php">
                    <span class="material-icons">insights</span> Accueil </a></li>
            <li><a href="../Demande_inscription/Demande_inscription.php">
                    <span class="material-icons">pending_actions</span> Demandes d'inscription </a></li>

            <li><a href="../Dons_cotisations/Dons_cotisations.php">
                    <span class="material-icons">volunteer_activism</span> Cotisation et dons </a></li>

            <li><a href="#">
                    <span class="material-icons">people</span> Membres inscrits </a></li>
            </a>
            <li><a href="../Archives/Archives.php">
                    <span class="material-icons">archive</span> Archives </a></li>

            <li><a href="../../Connexion/logout.php" id="logout-link">
                    <span class="material-icons">logout</span> Déconnexion</a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <section>
            <h2>Membres inscrits</h2>

            <!-- Search Bar -->
            <div class="search-bar">
                <input type="text" id="search-input" placeholder="Rechercher un membre...">
            </div>

            <table id="members-table">
                <thead>
                <tr>
                    <th class="select-column" style="display: none;">Select</th>
                    <th>Prénom</th>
                    <th>Nom</th>
                    <th>Adresse</th>
                    <th>Email</th>
                    <th>Téléphone</th>
                    <th>Date d'inscription</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php if (empty($members)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 20px;">Pas de membres pour l'instant!</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($members as $member): ?>
                        <tr>
                            <td class="select-column" style="display: none;"><input type="checkbox" class="member-checkbox" data-id="<?= $member['id'] ?>"></td>
                            <td><?= htmlspecialchars($member['first_name']) ?></td>
                            <td><?= htmlspecialchars($member['last_name']) ?></td>
                            <td><?= htmlspecialchars($member['adresse']) ?></td>
                            <td><?= htmlspecialchars($member['email']) ?></td>
                            <td><?= htmlspecialchars($member['phone']) ?></td>
                            <td><?= htmlspecialchars($member['joining_date']) ?></td>
                            <td>
                                <button class="edit-btn" data-id="<?= $member['id'] ?>">Edit</button>
                                <button class="save-btn" style="display: none;">Save</button>
                                <button class="cancel-btn" style="display: none;">Annuler</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
            <!-- Button to download table data as CSV -->
            <div id="initial-buttons" class="button-group">
                <button id="download-csv">Télécharger</button>
                <button id="print-table">Imprimer</button>
                <button id="add-member-btn">Ajouter un Membre</button>
                <button id="supprimer-btn">Supprimer</button>
            </div>

            <div id="delete-buttons" class="button-group" style="display: none;">
                <button id="confirm-delete" style="background-color: #FF4C4C;">Confirmer</button>
                <button id="select-all-btn">Sélectionner tout</button>
                <button id="cancel-btn">Annuler</button>
            </div>

            <!-- Hidden form for adding a new member -->
            <div id="add-member-form" style="display: none;">
                <h3>Ajouter un Nouveau Membre</h3>
                <form id="new-member-form">
                    <label for="first_name">Prénom :</label>
                    <input type="text" id="first_name" name="first_name" required><br><br>

                    <label for="last_name">Nom :</label>
                    <input type="text" id="last_name" name="last_name" required><br><br>

                    <label for="adresse">Adresse:</label>
                    <input type="text" id="adresse" name="adresse" required><br><br>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required><br><br>

                    <label for="phone">Téléphone:</label>
                    <input type="text" id="phone" name="phone" required><br><br>

                    <label for="joining_date">Date d'inscription:</label>
                    <input type="date" id="joining_date" name="joining_date" required><br><br>

                    <button type="submit" id="submit-new-member">Confirmer</button>
                    <button type="button" id="cancel-new-member">Annuler</button>
                </form>
            </div>
        </section>
    </div>
</div>

<script src="gestion_membres.js"></script>
</body>
</html>