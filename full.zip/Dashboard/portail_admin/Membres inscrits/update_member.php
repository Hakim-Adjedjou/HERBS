<?php
global $db;
require __DIR__ . '/../../db.php';

header('Content-Type: application/json');  // Ensure the response is JSON

try {
    // Get JSON input data
    $data = json_decode(file_get_contents('php://input'), true);

    if (
        empty($data['id']) ||
        empty($data['first_name']) ||
        empty($data['last_name']) ||
        empty($data['adresse']) ||  // Address field must not be empty
        empty($data['email']) ||
        empty($data['phone']) ||
        empty($data['joining_date'])
    ) {
        echo json_encode(['success' => false, 'message' => 'Missing or invalid data']);
        exit;
    }

    // Extract data
    $id = $data['id'];
    $first_name = $data['first_name'];
    $last_name = $data['last_name'];
    $adresse = $data['adresse'];
    $email = $data['email'];
    $phone = $data['phone'];
    $joining_date = $data['joining_date'];

    // Prepare and execute the update query
    $stmt = $db->prepare(
        "UPDATE members 
         SET first_name = :first_name, 
             last_name = :last_name, 
             adresse = :adresse, 
             email = :email, 
             phone = :phone, 
             joining_date = :joining_date 
         WHERE id = :id"
    );

    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':adresse', $adresse);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':joining_date', $joining_date);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Member updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update member']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>

